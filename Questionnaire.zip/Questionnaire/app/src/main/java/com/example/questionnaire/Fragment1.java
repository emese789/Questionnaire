package com.example.questionnaire;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import static androidx.constraintlayout.widget.Constraints.TAG;


public class Fragment1 extends Fragment {
    EditText name,expections;
    Spinner location,departemnt;
    Button image,send,list,date;
    DatePicker datePicker;
    RadioGroup genderoptions,yearoption;
    RadioButton gendergroup,yeargroup;
    CheckBox checkBox1,checkBox2;
    String birthDate;
    private static final int PICK_IMAGE_REQUEST = 1;
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_fragment1,container,false);
        name= v.findViewById(R.id.name_editText);
        location=v.findViewById(R.id.location_spinner);
        image=v.findViewById(R.id.image_button);
        date = v.findViewById(R.id.date_button);
        date.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                DatePickerDialog dialog = new DatePickerDialog(v.getContext());
                dialog.setOnDateSetListener(new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        birthDate = year + "." + month + "." + dayOfMonth;
                        Log.d(TAG, "Date: " + birthDate);
                    }
                });
                dialog.show();
            }
        });
        checkBox1=v.findViewById(R.id.checkBox1);
        checkBox2=v.findViewById(R.id.checkBox2);
        departemnt=v.findViewById(R.id.department_spinner);
        expections=v.findViewById(R.id.ex_editText);
        send=v.findViewById(R.id.send_button);
        genderoptions=v.findViewById(R.id.gendergroup);
        yearoption=v.findViewById(R.id.studyyear);
        list=v.findViewById(R.id.list_button);
        gendergroup=v.findViewById(R.id.gendergroup);
        yeargroup=v.findViewById(R.id.studyyear);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getActivity(),R.array.location, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        location.setAdapter(adapter);
        ArrayAdapter<CharSequence> dep_adapter = ArrayAdapter.createFromResource(getActivity(),R.array.departments, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        departemnt.setAdapter(dep_adapter);
        int radioID = genderoptions.getCheckedRadioButtonId();
        gendergroup = getView().findViewById(radioID);
        String gender = (String) gendergroup.getText();
        int yearId = yearoption.getCheckedRadioButtonId();
        yeargroup = getView().findViewById(yearId);
        String year = (String) yeargroup.getText();

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getActivity(), "Data inserted", Toast.LENGTH_LONG).show();
            }
        });

        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction fr=getFragmentManager().beginTransaction();
                fr.replace(R.id.fragment_container,new Fragment2());
                fr.commit();

            }
        });
        image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        return v;
    }
    private void chooseImage() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }
}

